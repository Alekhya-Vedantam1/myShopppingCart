var express = require('express');
var router = express.Router();
var mongoose =require('mongoose');
var assert=require('assert');
var Product = require('../models/product');
mongoose.connect('mongodb://localhost:27017/shopping', { useNewUrlParser: true });

var url='mongodb://localhost:27017';
const MongoClient =require('mongodb').MongoClient;
const client=new MongoClient(url);
const dbName='shopping';

/* GET home page. */
router.get('/', function(req, res, next) {
  Product.find(function(err,docs){
     var productChunks=[];
     var chunkSize=3;
     for(var i=0;i<docs.length;i +=chunkSize){
       productChunks.push(docs.slice(i,i+chunkSize));
     }
  
  res.render('shop/index', { title: 'Shopping Cart', products:productChunks });
    });
});


router.get('/get-data/:id',function(req,res,next){
  var productId=req.params.id;
   var upto=new 

  res.redirect('/update/:id');
});

router.post('/insert',function(req,res,next){
  var products=new Product({
    imagePath:req.body.image,
    title:req.body.title,
    description:req.body.description,
    price:req.body.price
  });
  products.save();
  res.redirect('/shop/adminindex');
});

router.put('/update/:id',function(req,res){
    const doc=({
      imagePath:req.body.image,
    title:req.body.title,
    description:req.body.description,
    price:req.body.price
    });
    Product.update({_id:req.params.id},doc,function(err,raw){
      if(err){
        res.send(err);
      }
      res.send(raw);
    });
  });
    

router.get('/delete/:id',function(req,res,next){
  mongoose.model("product").remove({_id:req.params.id},function(err,delData){
     res.redirect("/shop/adminindex");
  });
 

});
module.exports = router;
